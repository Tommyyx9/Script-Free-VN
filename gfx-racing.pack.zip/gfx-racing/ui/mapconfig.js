Config = {
    MaximumRouteCount : 200,
    MinimumRouteCountForAddRoute : 5,
    MainPageLeaderBoardLength : 5, 
    RacersPageLeaderBoardLength : 40,
}
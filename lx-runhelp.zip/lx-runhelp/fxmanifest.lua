fx_version 'cerulean'
game 'gta5'

description 'Choco-runhelp'
version '1.0.0'

ui_page('html/index.html')

client_script 'client.lua'

files({
    'html/css/style.css',
    'html/index.html',
    'html/js/config.js',
    'html/js/main.js',
    'html/img/*.*'
})

local QBCore = exports['qb-core']:GetCoreObject()

RegisterNetEvent("QBCore:Client:OnPlayerLoaded", function()
    SendNUIMessage({
        action = "startRunhelp",
    })
    -- print("hehe")
end)


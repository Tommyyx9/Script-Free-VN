var config = {
    //Cài đặt biểu ngữ
    banner: {
        fadeTime: '20000', //Thời Gian 
        interval: 10,
        messages: [
            "BẤM B ĐỂ THẮT DÂY AN TOÀN.",
            "BẤM M ĐỂ MỞ ĐIỆN THOẠI.",
            "BẤM TAB ĐỂ MỞ TÚI ĐỒ.",
            "BẤM L ĐỂ ĐÓNG MỞ CỬA XE.",
            "TRONG CÀI ĐẶT -> GRAPHICS GIẢM MỤC POST FX XUỐNG NORMAL CŨNG LÀ 1 CÁCH ĐỂ TĂNG FPS HIỆU QUẢ.",
            "F1 ĐỂ MỞ BẢNG MENU TƯƠNG TÁC.",
            "CẢNH BÁO MUA ĐỒ QUÁ SỐ KG NẶNG TRONG TÚI ĐỒ SẼ MẤT ĐỒ.",
            "F3 ĐỂ MỞ BẢNG EMOTEMENU.",
            "COMING SOON GIÁ Ở CHỢ SẼ THAY ĐỔI LIÊN TỤC HÀNG GIỜ.",
            "/HUD ĐỂ TÙY BIẾN MÀU SẮC HUD.",
            "F6 ĐỂ SỬ DỤNG BẢNG DỊCH VỤ.",
            "NHIỆM VỤ HÀNG NGÀY VÀ LỤC THÙNG RÁC SẼ GIÚP BẠN CÓ LOCKPICK.",
            "HÃY CẨN THẬN CÂY VAPE CỦA BẠN CÓ THỂ NỔ BẤT CỨ LÚC NÀO.",
        ]
    }
}
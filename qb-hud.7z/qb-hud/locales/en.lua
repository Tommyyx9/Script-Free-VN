local Translations = {

    notify = {

        ["hud_settings_loaded"] = "Cấu hình HUD đã được tải!",

        ["hud_restart"] = "HUD đang được khởi động lại!",

        ["hud_start"] = "HUD đã chạy!",

        ["hud_command_info"] = "Lệnh này sẽ khởi động lại HUD của bạn!",

        ["load_square_map"] = "Đang tải bản đồ vuông...",

        ["loaded_square_map"] = "Bản đồ vuông đã được tải!",

        ["load_circle_map"] = "Đang tải bản đồ tròn...",

        ["loaded_circle_map"] = "Bản đồ tròn đã được tải!",

        ["cinematic_on"] = "Chế độ điện ảnh: BẬT!",

        ["cinematic_off"] = "Chế độ điện ảnh: TẮT!",

        ["engine_on"] = "Động cơ đã khởi động!",

        ["engine_off"] = "Động cơ đã tắt!",

        ["low_fuel"] = "Xăng sắp hết!",

        ["access_denied"] = "Bạn không có quyền sử dụng!",

        ["stress_gain"] = "Bạn đang bị căng thẳng!",

        ["stress_removed"] = "Bạn đã bớt căng thẳng!"

    }

}

Lang = Locale:new({phrases = Translations, warnOnMissing = true})
local QBCore = exports['qb-core']:GetCoreObject()
local ResetStress = false

QBCore.Commands.Add('cash', 'Kiểm tra tiền mặt', {}, false, function(source, _)
    local Player = QBCore.Functions.GetPlayer(source)
    local cashamount = Player.PlayerData.money.cash
    TriggerClientEvent('hud:client:ShowAccounts', source, 'cash', cashamount)
end)


QBCore.Commands.Add("dev", "Enable/Disable developer Mode", {}, false, function(source, _)
    TriggerClientEvent("qb-admin:client:ToggleDevmode", source)
end, 'admin')

RegisterNetEvent('qb-hud:server:GainStress', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local newStress
    if not Player or (Config.DisablePoliceStress and Player.PlayerData.job.name == 'police') then return end
    if not ResetStress then
        if not Player.PlayerData.metadata['stress'] then
            Player.PlayerData.metadata['stress'] = 0
        end
        newStress = Player.PlayerData.metadata['stress'] + amount
        if newStress <= 0 then newStress = 0 end
    else
        newStress = 0
    end
    if newStress > 100 then
        newStress = 100
    end
    Player.Functions.SetMetaData('stress', newStress)
    TriggerClientEvent('qb-hud:client:UpdateStress', src, newStress)
    TriggerClientEvent('QBCore:Notify', src, "Bạn đang cảm thấy căng thẳng", 'error', 1500)
end)

RegisterNetEvent('qb-hud:server:RelieveStress', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local newStress
    if not Player then return end
    if not ResetStress then
        if not Player.PlayerData.metadata['stress'] then
            Player.PlayerData.metadata['stress'] = 0
        end
        newStress = Player.PlayerData.metadata['stress'] - amount
        if newStress <= 0 then newStress = 0 end
    else
        newStress = 0
    end
    if newStress > 100 then
        newStress = 100
    end
    Player.Functions.SetMetaData('stress', newStress)
    TriggerClientEvent('qb-hud:client:UpdateStress', src, newStress)
    TriggerClientEvent('QBCore:Notify', src, "Bạn đang cảm thấy thư giản")
end)


RegisterNetEvent('qb-hud:server:NhiemBenh', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local newStress
    if not Player or (Config.DisablePoliceStress and Player.PlayerData.job.name == 'police') then return end
    if not ResetStress then
        if not Player.PlayerData.metadata['stamina'] then
            Player.PlayerData.metadata['stamina'] = 0
        end
        newStress = Player.PlayerData.metadata['stamina'] + amount
        if newStress <= 0 then newStress = 0 end
    else
        newStress = 0
    end
    if newStress > 100 then
        newStress = 100
    end
    Player.Functions.SetMetaData('stamina', newStress)
    TriggerClientEvent('qb-hud:client:UpdateStamina', src, newStress)
    TriggerClientEvent('QBCore:Notify', src, "Bạn đang bị nhiễm bệnh", 'error', 1500)
end)

RegisterNetEvent('qb-hud:server:GiamBenh', function(amount)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    local newStress
    if not Player then return end
    if not ResetStress then
        if not Player.PlayerData.metadata['stamina'] then
            Player.PlayerData.metadata['stamina'] = 0
        end
        newStress = Player.PlayerData.metadata['stamina'] - amount
        if newStress <= 0 then newStress = 0 end
    else
        newStress = 0
    end
    if newStress > 100 then
        newStress = 100
    end
    Player.Functions.SetMetaData('stamina', newStress)
    TriggerClientEvent('qb-hud:client:UpdateStamina', src, newStress)
    TriggerClientEvent('QBCore:Notify', src, "Bạn đang cảm thấy khoẻ hơn")
end)


QBCore.Functions.CreateCallback('hud:server:getMenu', function(_, cb)
    cb(Config.Menu)
end)

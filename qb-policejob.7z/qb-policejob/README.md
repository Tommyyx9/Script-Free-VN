**👮ARIUS POLICEJOB 👮**

_Experience the ultimate law enforcement roleplay with Arius Policejob 👮. Restrain suspects, conduct thorough searches, issue fines, access police gear, and more. Explore a comprehensive system that brings realism and immersion to your policing adventures.!_

**Frameworks:**

-   ESX
-   Qb Core

**Dependencies:**

-   ox_inventory
-   ox_target
-   pickle_prisons / qalle-jail (if using arrest functionality)

**Features:**

-   HandCuffs system for restraining suspects
-   Suspect search functionality
-   Suspect escorting
-   Placing arrested suspects in police vehicles
-   Removing arrested suspects from vehicles
-   Seamless integration with popular jail scripts
-   Fine system for issuing penalties
-   Compatible with ESX and Qb Core frameworks
-   Access to police equipment from dedicated NPCs
-   Work clothes for realistic roleplay
-   Grade-based garage system for different police vehicles
-   Global and personal stashes for storing and sharing equipment
-   Designated crime areas with map blip functionality
-   Props like cones accessible from vehicle trunks
-   Breakable handcuffs with lockpicks
-   Accessible cameras for surveillance
-   PoliceMenu with cool options
-   Internal Duty
-   Otimized 0.0ms idle

**Download:**
https://github.com/Arius-Development/qb-policejob

**Installation**
https://ariuss-development.gitbook.io/ariusdevelopment/

**Forums:**
https://forum.cfx.re/t/free-esx-qbcore-arius-policejob/5128137

**Preview:**
https://youtu.be/Dh0MqgjwdG8

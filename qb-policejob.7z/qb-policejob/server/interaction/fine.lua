RegisterNetEvent('qb-policejob:finePlayer', function(target, amount, reason)
    if not hasJob(source, Config.Interactions.jobs) or not source or source < 1 then return end

    removeAccountMoney(target, 'bank', amount)
    TriggerClientEvent('qb-policejob:showNotification', target, locale('have_been_fined'):format(amount, reason))
end)

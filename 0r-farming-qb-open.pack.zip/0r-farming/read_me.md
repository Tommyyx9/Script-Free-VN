Thanks for your purchase!

<!-- 0RESMON -->

1- Download assets from here: https://drive.google.com/file/d/1m8ju02X0xldCiwk7bri29njBUs3KVQe2/view?usp=sharing

2- Set the resource name 0r-farming-QB to 0r-farming.

3- put the 0r-farming-assets and 0r-farming to your resource folder.

4- start your server have fun!

If you have errors or questions please open 0R category ticket and tag @JezzyOnDuty from our discord: https://discord.com/invite/0resmon